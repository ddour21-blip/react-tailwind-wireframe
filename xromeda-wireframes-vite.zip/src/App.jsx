import React, { useState } from "react";

/**
 * XRomeda Channel Wireframes (Interactive)
 * - Top 5 tabs: Home / Store / Community / About / More (sheet)
 * - Store sub-tabs: Membership | VROOK | XR Fan Meeting
 * - Screens: Home, Store>VROOK, Store>XR, Community, About
 *
 * Wireframe style: dashed borders, grayscale blocks, labels.
 */

const Tab = ({ active, children, onClick }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 rounded-md text-sm font-medium border ${
      active ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-700 border-gray-300"
    }`}
  >
    {children}
  </button>
);

const Pill = ({ active, children, onClick }) => (
  <button
    onClick={onClick}
    className={`px-3 py-1 rounded-full text-xs font-semibold border ${
      active ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-700 border-gray-300"
    }`}
  >
    {children}
  </button>
);

const Block = ({ title, children, right }) => (
  <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 bg-gray-50">
    <div className="flex items-center justify-between mb-2">
      <div className="text-xs uppercase tracking-wider text-gray-500">{title}</div>
      {right}
    </div>
    {children}
  </div>
);

const Hero = ({ title, subtitle, extra }) => (
  <Block title="HERO / 헤더">
    <div className="flex items-center gap-6">
      <div className="w-40 h-40 rounded-xl bg-gray-200 border border-dashed" />
      <div className="flex-1">
        <div className="text-2xl font-bold mb-2">{title}</div>
        <div className="text-sm text-gray-600 mb-3">{subtitle}</div>
        <div className="flex gap-2 text-xs">
          <span className="px-2 py-1 rounded bg-gray-200">#tag</span>
          <span className="px-2 py-1 rounded bg-gray-200">#tag</span>
          <span className="px-2 py-1 rounded bg-gray-200">Follow</span>
          <span className="px-2 py-1 rounded bg-gray-200">Share</span>
        </div>
      </div>
      {extra}
    </div>
  </Block>
);

const PackageCard = ({ title, price, bullets, badge, ctaLabel }) => (
  <div className="border border-dashed border-gray-300 rounded-xl p-4 bg-white flex flex-col gap-3">
    <div className="h-28 rounded-lg bg-gray-100 border border-dashed" />
    <div className="flex items-center justify-between">
      <div>
        <div className="font-semibold">{title}</div>
        <div className="text-sm text-gray-500">₩{price.toLocaleString()} / $xx.x</div>
      </div>
      <span className="text-[10px] px-2 py-1 rounded-full bg-gray-900 text-white">{badge}</span>
    </div>
    <ul className="text-sm list-disc list-inside text-gray-600">
      {bullets.map((b, i) => (
        <li key={i}>{b}</li>
      ))}
    </ul>
    <button className="mt-auto w-full py-2 text-sm font-semibold rounded-md bg-gray-900 text-white">
      {ctaLabel}
    </button>
  </div>
);

const ContentCard = ({ title, type, locked, primary, secondary }) => (
  <div className="border border-dashed border-gray-300 rounded-xl p-3 bg-white flex flex-col gap-3">
    <div className={`h-28 rounded-lg ${locked ? "bg-gray-200" : "bg-gray-100"} border border-dashed flex items-center justify-center text-xs text-gray-500`}>
      THUMB ({type}) {locked && "/ 잠금"}
    </div>
    <div className="text-sm font-medium">{title}</div>
    <div className="flex gap-2">
      {primary && (
        <button className="px-3 py-1 text-xs rounded-md bg-gray-900 text-white">{primary}</button>
      )}
      {secondary && (
        <button className="px-3 py-1 text-xs rounded-md bg-gray-200">{secondary}</button>
      )}
    </div>
  </div>
);

// New component for recent content on the home page
const RecentContentCard = ({ title, description, likes, comments }) => (
  <div className="border border-dashed border-gray-300 rounded-xl bg-white flex flex-col">
    <div className="h-40 rounded-t-lg bg-gray-100 border-b border-dashed flex items-center justify-center text-xs text-gray-500">
      THUMBNAIL
    </div>
    <div className="p-4 flex flex-col gap-3 flex-grow">
      <h3 className="font-bold">{title}</h3>
      <p className="text-sm text-gray-600 flex-grow">{description}</p>
      <div className="flex items-center gap-4 text-xs text-gray-500">
        <span>❤️ {likes}</span>
        <span>💬 {comments}</span>
        <span className="ml-auto">...</span>
        <span>🔗</span>
      </div>
      <div className="flex gap-2 mt-2">
        <button className="flex-1 py-2 text-xs rounded-md bg-gray-900 text-white">패키지 구매</button>
        <button className="flex-1 py-2 text-xs rounded-md bg-gray-200">멤버십 보기</button>
      </div>
    </div>
  </div>
);

// New component for the channel header
const ChannelHeader = ({ topTabs, mainTab, setMainTab, setMoreOpen, moreOpen }) => (
  <div className="bg-white border-b border-gray-200">
    <div className="h-48 bg-gray-200 border-b border-dashed relative flex items-center justify-center">
      <span className="text-gray-500 text-sm">배너 이미지</span>
    </div>
    <div className="max-w-6xl mx-auto px-4 relative">
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 rounded-full bg-gray-100 border-4 border-white border-dashed flex items-center justify-center">
        <span className="text-gray-500 text-xs">로고</span>
      </div>
      <div className="pt-16 pb-4 text-center">
        <h2 className="text-2xl font-bold">채널 이름</h2>
        <p className="text-sm text-gray-500 mt-2 max-w-md mx-auto">채널 설명이 여기에 들어갑니다. 팬들에게 채널에 대해 알려주세요.</p>
        <button className="mt-4 px-6 py-2 bg-gray-900 text-white text-sm font-semibold rounded-md">무료로 가입하기</button>
      </div>
      <div className="flex items-center gap-2 justify-center">
        {topTabs.map((t) => (
          <Tab
            key={t.key}
            active={mainTab === t.key}
            onClick={() => {
              if (t.key === "more") {
                setMoreOpen((v) => !v);
              } else {
                setMoreOpen(false);
                setMainTab(t.key);
              }
            }}
          >
            {t.label}
          </Tab>
        ))}
        {moreOpen && (
          <div className="ml-2 px-3 py-2 rounded-lg border bg-white text-xs shadow absolute mt-12">펀딩 · 후원 · 단건</div>
        )}
      </div>
    </div>
  </div>
);

export default function App() {
  const [mainTab, setMainTab] = useState("home");
  const [storeTab, setStoreTab] = useState("vrook"); // membership | vrook | xr
  const [moreOpen, setMoreOpen] = useState(false);

  const topTabs = [
    { key: "home", label: "홈" },
    { key: "store", label: "스토어" },
    { key: "community", label: "커뮤니티" },
    { key: "about", label: "소개" },
    { key: "more", label: "더보기" },
  ];

  const renderStore = () => (
    <div className="space-y-4">
      {/* Sub Tabs as Pills */}
      <div className="flex items-center gap-2">
        <Pill active={storeTab === "membership"} onClick={() => setStoreTab("membership")}>
          멤버십
        </Pill>
        <Pill active={storeTab === "vrook"} onClick={() => setStoreTab("vrook")}>
          VROOK
        </Pill>
        <Pill active={storeTab === "xr"} onClick={() => setStoreTab("xr")}>
          XR 팬미팅
        </Pill>
        <span className="ml-auto text-xs text-gray-500">딥링크: /@:id/store?tab={storeTab}</span>
      </div>

      {storeTab === "membership" && (
        <div className="space-y-4">
          <Hero title="멤버십" subtitle="구독으로 모든 멤버십 전용 콘텐츠 접근" />
          <Block title="멤버십 플랜(최대 5)">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <PackageCard
                  key={i}
                  title={`플랜 ${i}`}
                  price={5000 * i}
                  bullets={["전용 포스트", "라이브", "배지"]}
                  badge="판매중"
                  ctaLabel="멤버십 보기"
                />
              ))}
            </div>
          </Block>
          <Block title="전용 콘텐츠 그리드">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[...Array(6)].map((_, i) => (
                <ContentCard key={i} title={`멤버십 포스트 ${i + 1}`} type="POST" locked={false} />
              ))}
            </div>
          </Block>
        </div>
      )}

      {storeTab === "vrook" && (
        <div className="space-y-4">
          <Hero title="VROOK" subtitle="디지털 화보 · 메이킹 · VR 묶음 패키지" />
          <Block title="패키지 안내(최대 3종)" right={<span className="text-xs text-gray-500">상태: 판매중/예약/품절/종료</span>}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <PackageCard title="브이룩 패키지" price={39000} bullets={["메인 화보 20", "메이킹 1", "VR 1"]} badge="판매중" ctaLabel="구매하기" />
              <PackageCard title="스페셜" price={59000} bullets={["메인 화보 20", "메이킹 1", "VR 풀버전 1", "보너스"]} badge="예약" ctaLabel="구매하기" />
              <PackageCard title="ALL" price={79000} bullets={["메인+B컷 40", "AI 포토카드", "VR 풀버전", "실물 굿즈"]} badge="판매중" ctaLabel="구매하기" />
            </div>
          </Block>
          <Block title="콘텐츠 안내 (패키지 선택 칩)">
            <div className="flex gap-2 mb-3 text-xs">
              <Pill active>전체</Pill>
              <Pill>브이룩 패키지</Pill>
              <Pill>스페셜</Pill>
              <Pill>ALL</Pill>
              <span className="ml-auto text-gray-500">정렬: 최신/인기/구성순</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <ContentCard title="메인 화보" type="IMAGE" locked primary="패키지 구매" secondary="멤버십 보기" />
              <ContentCard title="메이킹" type="VIDEO" locked primary="패키지 구매" />
              <ContentCard title="VR 영상" type="VR" locked primary="패키지 구매" />
              <ContentCard title="AI 포토카드" type="IMAGE" locked primary="패키지 구매" />
              <ContentCard title="B컷" type="IMAGE" locked primary="패키지 구매" />
              <ContentCard title="보너스" type="VIDEO" locked primary="패키지 구매" />
            </div>
          </Block>
        </div>
      )}

      {storeTab === "xr" && (
        <div className="space-y-4">
          <Hero title="XR 콘서트" subtitle="라이브 시청 · 실시간 채팅 · 1:1 대화 · 다시보기" />
          <Block title="공지(일정)">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
              <div className="p-3 rounded-lg bg-gray-100 border border-dashed">공연 일시/타임존</div>
              <div className="p-3 rounded-lg bg-gray-100 border border-dashed">예매 오픈/마감 · 진행 방식</div>
              <div className="p-3 rounded-lg bg-gray-100 border border-dashed">알림(T-30/T-5) · FAQ</div>
            </div>
          </Block>
          <Block title="패키지 안내(최대 3종)">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <PackageCard title="기본" price={29000} bullets={["라이브 시청", "실시간 채팅", "XR 공용 존"]} badge="판매중" ctaLabel="예매하기" />
              <PackageCard title="프리미엄" price={49000} bullets={["+ 1:1 대화 2분", "+ 다시보기 30일"]} badge="마감임박" ctaLabel="예매하기" />
              <PackageCard title="VIP" price={99000} bullets={["+ 1:1 대화 5분", "+ 사인회(XR)", "+ 굿즈 배송"]} badge="예정" ctaLabel="예매하기" />
            </div>
          </Block>
          <Block title="콘텐츠 안내">
            <div className="flex gap-2 mb-3 text-xs">
              <Pill active>전체</Pill>
              <Pill>기본</Pill>
              <Pill>프리미엄</Pill>
              <Pill>VIP</Pill>
              <span className="ml-auto text-gray-500">상태: 예정/진행중/종료/다시보기</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <ContentCard title="라이브 입장권" type="LIVE" locked primary="예매하기" />
              <ContentCard title="녹화본(VOD)" type="VOD" locked primary="예매하기" />
              <ContentCard title="포토존" type="IMAGE" locked primary="예매하기" />
              <ContentCard title="굿즈 안내" type="CARD" locked primary="예매하기" />
            </div>
          </Block>
        </div>
      )}
    </div>
  );

  const renderHome = () => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Recent Contents */}
      <div className="lg:col-span-2 space-y-4">
        <h2 className="text-lg font-bold">최근 콘텐츠</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <RecentContentCard title="트룹야 AI 포토카드 | AI Photo Cards" description="ChatGPT 보다 더 섹시한 트룹야를 AI 화보로 만나봐요" likes={67} comments={7} />
          <RecentContentCard title="한순간도 놓칠 수 없다 에겠더 모습 트룹야 | Special B-cuts" description="버섯들에게 B컷으로 특별한 순간을 조금 더 준비해봤어요." likes={72} comments={4} />
          <RecentContentCard title="(G)I-DLE 'Revenge Room' [2]" description="(여자)아이들 'Revenge Room'에서 다양한 콘텐츠 및 이벤트를 참여하세요!" likes={154} comments={117} />
        </div>
      </div>
      {/* Popular Contents */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold">인기 콘텐츠</h2>
        <div className="space-y-3">
          {[
            { title: "(G)I-DLE's 2nd Full Album [2]", date: "2024.01.22" },
            { title: "(G)I-DLE 'Revenge Room'", date: "2024.02.23" },
          ].map((item, index) => (
            <div key={index} className="flex items-center gap-3 p-2 rounded-lg border border-dashed bg-white">
              <div className="w-16 h-16 bg-gray-100 rounded-md border border-dashed"></div>
              <div className="flex-1">
                <p className="font-semibold text-sm">{item.title}</p>
                <p className="text-xs text-gray-500">{item.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCommunity = () => (
    <div className="space-y-4">
      <Block title="커뮤니티 서브탭">
        <div className="flex gap-2">
          <Pill active>팬톡 (3)</Pill>
          <Pill>팬보드 (12)</Pill>
          <span className="ml-auto text-xs text-gray-500">/@:id/community?tab=chat|board</span>
        </div>
      </Block>
      <Block title="채팅/게시글 영역">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="col-span-2 h-60 rounded-xl border border-dashed bg-gray-100 flex items-center justify-center text-gray-500">메시지/게시글 리스트</div>
          <div className="h-60 rounded-xl border border-dashed bg-gray-100 flex items-center justify-center text-gray-500">새 글/입력</div>
        </div>
      </Block>
    </div>
  );

  const renderAbout = () => (
    <div className="space-y-4">
      <Hero title="소개" subtitle="채널 설명 · 크리에이터 정보" />
      <Block title="상세 프로필">
        <div className="h-40 rounded-xl border border-dashed bg-gray-100" />
      </Block>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 text-gray-800">
      {/* Channel Header */}
      <ChannelHeader
        topTabs={topTabs}
        mainTab={mainTab}
        setMainTab={setMainTab}
        moreOpen={moreOpen}
        setMoreOpen={setMoreOpen}
      />

      {/* Body */}
      <div className="max-w-6xl mx-auto p-4 space-y-4">
        {mainTab === "home" && renderHome()}
        {mainTab === "store" && renderStore()}
        {mainTab === "community" && renderCommunity()}
        {mainTab === "about" && renderAbout()}
      </div>
    </div>
  );
}
